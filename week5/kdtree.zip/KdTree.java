import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

public class KdTree {
    // construct an empty set of points
    private int numPoints;
    private Node root;

    private static class Node {

        private final Point2D p;
        private final RectHV rect;
        private final boolean isVertical;
        private Node leftOrBottom, rightOrUpper;

        // Define construction function
        Node(Point2D p, RectHV rect, boolean isVertical) {
            this.p = p;
            this.rect = rect;
            this.isVertical = isVertical;
        }

        // Define compareTo method
        int compareTo(Point2D that) {
            isNull(that);
            if (this.p.equals(that)) return 0;
            else if (isVertical) return this.p.x() > that.x() ? 1 : -1;
            else return this.p.y() > that.y() ? 1 : -1;
        }
    }

    // Construct an empty KdTree
    public KdTree() {
    }

    // is the tree empty?
    public boolean isEmpty() {
        return numPoints == 0;
    }

    // number of points in the tree
    public int size() {
        return numPoints;
    }

    // add the point to the set (if it is not already in the set)
    public void insert(Point2D p) {
        isNull(p);
        root = insert(p, root, null, 0);
    }

    // Define a recursive inserting function
    private Node insert(Point2D p, Node curNode, Node parent, int isParentLarger) {
        if (curNode == null) {
            if (numPoints++ == 0) return new Node(p, new RectHV(0, 0, 1, 1), true);
            RectHV rect;
            if (parent.isVertical) {
                if (isParentLarger > 0) {
                    rect = new RectHV(parent.rect.xmin(), parent.rect.ymin(), parent.p.x(),
                                      parent.rect.ymax());
                }
                else {
                    rect = new RectHV(parent.p.x(), parent.rect.ymin(), parent.rect.xmax(),
                                      parent.rect.ymax());
                }
            }
            else {
                if (isParentLarger > 0) {
                    rect = new RectHV(parent.rect.xmin(), parent.rect.ymin(), parent.rect.xmax(),
                                      parent.p.y());
                }
                else {
                    rect = new RectHV(parent.rect.xmin(), parent.p.y(), parent.rect.xmax(),
                                      parent.rect.ymax());
                }
            }
            return new Node(p, rect, !parent.isVertical);
        }
        else {
            int isLarger = curNode.compareTo(p);
            if (isLarger > 0)
                curNode.leftOrBottom = insert(p, curNode.leftOrBottom, curNode, isLarger);
            else if (isLarger < 0)
                curNode.rightOrUpper = insert(p, curNode.rightOrUpper, curNode, isLarger);

            return curNode;
        }
    }

    // does the set contain point p?
    public boolean contains(Point2D p) {
        isNull(p);
        return contains(p, root);
    }

    private static boolean contains(Point2D p, Node node) {
        if (node == null) return false;
        int isEqual = node.compareTo(p);
        if (isEqual > 0) return contains(p, node.leftOrBottom);
        else if (isEqual < 0) return contains(p, node.rightOrUpper);
        else return true;
    }

    // draw all points to standard draw
    public void draw() {
        draw(root);
    }

    private static void draw(Node node) {
        if (node == null) return;

        draw(node.leftOrBottom);
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.setPenRadius(0.01);
        node.p.draw();
        StdDraw.setPenRadius();
        if (node.isVertical) {
            StdDraw.setPenColor(StdDraw.RED);
            StdDraw.line(node.p.x(), node.rect.ymin(), node.p.x(), node.rect.ymax());
        }
        else {
            StdDraw.setPenColor(StdDraw.BLUE);
            StdDraw.line(node.rect.xmin(), node.p.y(), node.rect.xmax(), node.rect.xmax());
        }

        draw(node.rightOrUpper);
    }

    // all points that are inside the rectangle (or on the boundary)
    public Iterable<Point2D> range(RectHV rect) {
        isNull(rect);
        Queue<Point2D> pointQueue = new Queue<>();

        range(rect, root, pointQueue);
        return pointQueue;
    }

    // define the recursive range function
    private static void range(RectHV rect, Node node, Queue<Point2D> pointQueue) {
        if (node == null) return;
        if (rect.contains(node.p)) pointQueue.enqueue(node.p);
        if (node.leftOrBottom != null && rect.intersects(node.leftOrBottom.rect))
            range(rect, node.leftOrBottom, pointQueue);
        if (node.rightOrUpper != null && rect.intersects(node.rightOrUpper.rect))
            range(rect, node.rightOrUpper, pointQueue);
    }

    // a nearest neighbor in the set to point p; null if the set is empty
    public Point2D nearest(Point2D p) {
        isNull(p);

        if (isEmpty()) return null;
        return nearest(root, root.p, p);
    }

    // define the recursive nearest function
    private Point2D nearest(Node curNode, Point2D nearest, Point2D aimPoint) {
        if (curNode != null) {
            if (aimPoint.distanceSquaredTo(curNode.p) < aimPoint.distanceSquaredTo(nearest))
                nearest = curNode.p;
            int isLarger = curNode.compareTo(aimPoint);
            if (isLarger > 0) {
                nearest = nearest(curNode.leftOrBottom, nearest, aimPoint);
                if (curNode.rightOrUpper != null
                        && curNode.rightOrUpper.rect.distanceSquaredTo(aimPoint) < nearest
                        .distanceSquaredTo(aimPoint)) {
                    nearest = nearest(curNode.rightOrUpper, nearest, aimPoint);
                }
            }
            else if (isLarger < 0) {
                nearest = nearest(curNode.rightOrUpper, nearest, aimPoint);
                if (curNode.leftOrBottom != null
                        && curNode.leftOrBottom.rect.distanceSquaredTo(aimPoint) < nearest
                        .distanceSquaredTo(aimPoint))
                    nearest = nearest(curNode.leftOrBottom, nearest, aimPoint);
            }
        }

        return nearest;
    }

    // unit testing of the methods (optional)
    public static void main(String[] args) {
        PointSET ps = new PointSET();
        StdOut.println(ps.nearest(new Point2D(0, 0)) == null);
    }

    private static void isNull(Object obj) {
        if (obj == null) throw new IllegalArgumentException();
    }
}
