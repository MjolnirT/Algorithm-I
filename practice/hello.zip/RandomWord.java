import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {
    public static void main(String[] args) {
        String out = "";
        int i = 1;

        while (!StdIn.isEmpty()) {

            String temp = StdIn.readString();

            if (StdRandom.bernoulli((double) 1 / i)) {

                out = temp;
            }
            
            i++;
        }

        System.out.println(out);
    }
}
