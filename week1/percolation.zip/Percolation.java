import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final int size;
    private boolean[] status;
    private boolean[] topConnected;
    private boolean[] bottomConnected;
    private final WeightedQuickUnionUF ufWeight;

    private int numOpened = 0;
    private boolean isPercolated = false;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        boundaryCheck(n);
        this.size = n;
        this.status = new boolean[n * n];
        this.topConnected = new boolean[n * n];
        this.bottomConnected = new boolean[n * n];
        this.ufWeight = new WeightedQuickUnionUF(n * n);
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        boundaryCheck(row, col);
        int index = xy2index(row, col);
        if (!status[index]) {
            status[index] = true;
            numOpened++;
        }
        else {
            return;
        }

        boolean point2top = false;
        boolean point2bottom = false;

        if (row == 1) {
            point2top = true;
        }
        if (row == size) {
            point2bottom = true;
        }

        int targetIndex = index - size;
        if (row > 1 && status[targetIndex]) {
            if (topConnected[ufWeight.find(targetIndex)]) {
                point2top = true;
            }
            if (!point2bottom && bottomConnected[ufWeight.find(targetIndex)]) {
                point2bottom = true;
            }
            ufWeight.union(index, targetIndex);
        }

        targetIndex = index + size;
        if (row < size && status[targetIndex]) {
            if (!point2top && topConnected[ufWeight.find(targetIndex)]) {
                point2top = true;
            }
            if (!point2bottom && bottomConnected[ufWeight.find(targetIndex)]) {
                point2bottom = true;
            }
            ufWeight.union(index, targetIndex);
        }

        targetIndex = index - 1;
        if (col > 1 && status[targetIndex]) {
            if (!point2top && topConnected[ufWeight.find(targetIndex)]) {
                point2top = true;
            }
            if (!point2bottom && bottomConnected[ufWeight.find(targetIndex)]) {
                point2bottom = true;
            }
            ufWeight.union(index, targetIndex);
        }

        targetIndex = index + 1;
        if (col < size && status[targetIndex]) {
            if (!point2top && topConnected[ufWeight.find(targetIndex)]) {
                point2top = true;
            }
            if (!point2bottom && bottomConnected[ufWeight.find(targetIndex)]) {
                point2bottom = true;
            }
            ufWeight.union(index, targetIndex);
        }


        topConnected[ufWeight.find(index)] = point2top;
        bottomConnected[ufWeight.find(index)] = point2bottom;
        if (point2top && point2bottom) {
            isPercolated = true;
        }

    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        boundaryCheck(row, col);
        return status[xy2index(row, col)];
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        boundaryCheck(row, col);
        return topConnected[ufWeight.find(xy2index(row, col))];
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return numOpened;
    }

    // does the system percolate?
    public boolean percolates() {
        return isPercolated;
    }

    // test client (optional)
    public static void main(String[] args) {
        //
    }

    private void boundaryCheck(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException();
        }
    }

    private void boundaryCheck(int row, int col) {
        if (row <= 0 || row > size || col <= 0 || col > size) {
            throw new IllegalArgumentException();
        }
    }

    private int xy2index(int row, int col) {
        boundaryCheck(row, col);
        return (row - 1) * size + col - 1;
    }
}
