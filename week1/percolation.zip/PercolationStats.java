import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private static final double NORMAL_95 = 1.96;
    private final double mean;
    private final double std;
    private final double ciUpper;
    private final double ciLower;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int size, int trials) {
        if (size <= 0 || trials <= 0) {
            throw new IllegalArgumentException();
        }
        double[] thresholds = new double[trials];
        for (int trialIndex = 0; trialIndex < trials; trialIndex++) {
            Percolation p = new Percolation(size);
            while (!p.percolates()) {
                int row = StdRandom.uniform(1, size + 1);
                int col = StdRandom.uniform(1, size + 1);
                p.open(row, col);
            }
            thresholds[trialIndex] = (double) p.numberOfOpenSites() / (size * size);
        }

        mean = StdStats.mean(thresholds);
        std = StdStats.stddev(thresholds);
        ciUpper = mean + (NORMAL_95 * std) / Math.sqrt(trials);
        ciLower = mean - (NORMAL_95 * std) / Math.sqrt(trials);
    }

    // sample mean of percolation threshold
    public double mean() {
        return mean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return std;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return ciLower;
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return ciUpper;
    }

    // test client (see below)
    public static void main(String[] args) {
        int size = Integer.parseInt(args[0]);
        int trails = Integer.parseInt(args[1]);
        PercolationStats ps = new PercolationStats(size, trails);

        StdOut.println("mean                    = " + ps.mean());
        StdOut.println("stddev                  = " + ps.stddev());
        StdOut.println(
                "95% confidence interval = "
                        + "[" + ps.confidenceLo() + ", " + ps.confidenceHi() + "]");
    }

}
