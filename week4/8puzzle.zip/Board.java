import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;

public class Board {

    private final int[][] tiles;
    private final int n;
    private int hammingDistance = -1;
    private int manhattanDistance = -1;

    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] tiles) {
        n = tiles.length;
        this.tiles = new int[n][n];
        for (int i = 0; i < n; i++) {
            this.tiles[i] = Arrays.copyOf(tiles[i], n);
        }
    }

    // string representation of this board
    public String toString() {
        StringBuilder stringPuzzle = new StringBuilder();
        stringPuzzle.append(n).append("\n");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                stringPuzzle.append(String.format("%2d ", tiles[i][j]));
            }
            stringPuzzle.append("\n");
        }
        return stringPuzzle.toString();
    }

    // board dimension n
    public int dimension() {
        return n;
    }

    // number of tiles out of place
    public int hamming() {
        if (hammingDistance == -1) {
            hammingDistance = 0;
            for (int row = 0; row < n; row++) {
                for (int col = 0; col < n; col++) {
                    if (tiles[row][col] != 0 && tiles[row][col] != tileGoal(row, col)) {
                        hammingDistance++;
                    }
                }
            }
        }

        return hammingDistance;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan() {
        if (manhattanDistance == -1) {
            manhattanDistance = 0;
            for (int row = 0; row < n; row++) {
                for (int col = 0; col < n; col++) {
                    int tileValue = tiles[row][col];
                    if (tileValue != 0 && tileValue != tileGoal(row, col)) {
                        int rowGoal = (tileValue - 1) / n;
                        int colGoal = tileValue - rowGoal * n - 1;
                        manhattanDistance += Math.abs(rowGoal - row) + Math.abs(colGoal - col);
                    }
                }
            }
        }

        return manhattanDistance;
    }

    // is this board the goal board?
    public boolean isGoal() {
        return hamming() == 0;
    }

    // does this board equal y?
    public boolean equals(Object y) {
        if (y == this) return true;
        if (y == null) return false;
        if (y.getClass() != this.getClass()) return false;
        Board that = (Board) y;
        return Arrays.deepEquals(this.tiles, that.tiles);
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {
        int rowBlank = 0, colBlank = 0;
        isBlank:
        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                if (tiles[row][col] == 0) {
                    rowBlank = row;
                    colBlank = col;
                    break isBlank;
                }
            }
        }

        Stack<Board> neighborStack = new Stack<>();
        Board neighbor;
        // left neighbor by exchanging the blank with its left tile
        if (colBlank != 0) {
            neighbor = new Board(tiles);
            neighbor.exch(rowBlank, colBlank, rowBlank, colBlank - 1);
            neighborStack.push(neighbor);
        }
        // right neighbor by exchanging the blank with its right tile
        if (colBlank != n - 1) {
            neighbor = new Board(tiles);
            neighbor.exch(rowBlank, colBlank, rowBlank, colBlank + 1);
            neighborStack.push(neighbor);
        }
        // upper neighbor by exchanging the blank with its upper tile
        if (rowBlank != 0) {
            neighbor = new Board(tiles);
            neighbor.exch(rowBlank, colBlank, rowBlank - 1, colBlank);
            neighborStack.push(neighbor);
        }
        // lower neighbor by exchanging the blank with its lower tile
        if (rowBlank != n - 1) {
            neighbor = new Board(tiles);
            neighbor.exch(rowBlank, colBlank, rowBlank + 1, colBlank);
            neighborStack.push(neighbor);
        }

        return neighborStack;
    }

    // a board that is obtained by exchanging any pair of tiles
    public Board twin() {
        Board twinBoard = new Board(tiles);
        for (int col = 0; col < 2; col++) {
            if (twinBoard.tiles[0][col] != 0 && twinBoard.tiles[1][col] != 0) {
                twinBoard.exch(0, col, 1, col);
                return twinBoard;
            }
        }

        throw new IllegalArgumentException();
    }

    private int tileGoal(int row, int col) {
        if (row == n - 1 && col == n - 1) {
            return 0;
        }
        return row * n + col + 1;
    }

    private void exch(int rowSrc, int colSrc, int rowDst, int colDst) {
        assert (rowSrc >= 0 && rowSrc <= n - 1);
        assert (colSrc >= 0 && colSrc <= n - 1);
        assert (rowDst >= 0 && rowDst <= n - 1);
        assert (colDst >= 0 && colDst <= n - 1);

        int temp = tiles[rowSrc][colSrc];
        tiles[rowSrc][colSrc] = tiles[rowDst][colDst];
        tiles[rowDst][colDst] = temp;
    }

    // unit testing (not graded)
    public static void main(String[] args) {
        // unit tests (not graded)
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);
        StdOut.println(initial);
    }
}
