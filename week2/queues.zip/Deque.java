import edu.princeton.cs.algs4.StdOut;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

    private int size;
    private final Node head;

    private class Node {
        private Item item;
        private Node first;
        private Node next;

        Node(Item item) {
            this.item = item;
            this.first = null;
            this.next = null;
        }

        Node(Item item, Node first, Node next) {
            this.item = item;
            this.first = first;
            this.next = next;
        }

        void remove() {
            this.first.next = this.next;
            this.next.first = this.first;
            this.item = null;
            this.first = null;
            this.next = null;
        }
    }

    // construct an empty deque
    public Deque() {
        head = new Node(null);
        head.first = head;
        head.next = head;
        size = 0;
    }

    // is the deque empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the deque
    public int size() {
        return size;
    }

    // add the item to the front
    public void addFirst(Item item) {
        nullCheck(item);
        addNode(item, head, head.next);
        ++size;
    }

    // add the item to the back
    public void addLast(Item item) {
        nullCheck(item);
        addNode(item, head.first, head);
        ++size;
    }

    // remove and return the item from the front
    public Item removeFirst() {
        nullCheck();
        Item item = head.next.item;
        head.next.remove();
        --size;
        return item;
    }

    // remove and return the item from the back
    public Item removeLast() {
        nullCheck();
        Item item = head.first.item;
        head.first.remove();
        --size;
        return item;
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {
        return new DequeIterator();
    }

    private class DequeIterator implements Iterator<Item> {
        private Node now = head.next;

        public boolean hasNext() {
            return now != head;
        }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            now = now.next;
            return now.first.item;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // unit testing (required)
    public static void main(String[] args) {
        Deque<Integer> deque = new Deque<>();
        for (int i = 0; i < 10; i++) {
            deque.addFirst(i);
            deque.addLast(i + 1);
        }
        for (int integer : deque) {
            StdOut.print(integer + " ");
        }
        StdOut.println(" size: " + deque.size());

        for (int i = 0; i < 3; i++) {
            deque.removeFirst();
            deque.removeLast();
        }
        for (int integer : deque) StdOut.print(integer + " ");
        StdOut.println(" size: " + deque.size());

        for (int i = 0; i < 6; i += 2) {
            deque.addLast(i);
            deque.addFirst(i + 1);
        }
        for (int integer : deque) StdOut.print(integer + " ");
        StdOut.println(" size: " + deque.size());
    }

    private void nullCheck(Item item) {
        if (item == null) throw new IllegalArgumentException();
    }

    private void nullCheck() {
        if (isEmpty()) throw new NoSuchElementException();
    }

    private void addNode(Item item, Node first, Node next) {
        Node temp = new Node(item, first, next);
        first.next = temp;
        next.first = temp;
    }
}
