import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {

    private int size;
    private Item[] items;

    // construct an empty randomized queue
    public RandomizedQueue() {
        this.size = 0;
        this.items = (Item[]) new Object[1];
    }

    // is the randomized queue empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the randomized queue
    public int size() {
        return size;
    }

    // add the item
    public void enqueue(Item item) {
        nullCheck(item);
        if (items.length == size) {
            resize(items.length * 2);
        }
        items[size++] = item;
    }

    // remove and return a random item
    public Item dequeue() {
        nullCheck();
        int randInt = StdRandom.uniform(size);
        Item item = items[randInt];
        items[randInt] = items[--size];
        items[size] = null;
        if (size > 0 && size == items.length / 4) {
            resize(items.length / 2);
        }
        return item;
    }

    // return a random item (but do not remove it)
    public Item sample() {
        nullCheck();
        return items[StdRandom.uniform(size)];
    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }

    private class RandomizedQueueIterator implements Iterator<Item> {
        private final int[] randIndex;
        private int now;

        public RandomizedQueueIterator() {
            randIndex = new int[size];
            for (int i = 0; i < size; i++) {
                randIndex[i] = i;
            }
            StdRandom.shuffle(randIndex);
            now = 0;
        }

        public boolean hasNext() {
            return now != randIndex.length;
        }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            return items[randIndex[now++]];
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // unit testing (required)
    public static void main(String[] args) {
        RandomizedQueue<Integer> items = new RandomizedQueue<>();
        for (int i = 0; i < 10; i++) {
            items.enqueue(i);
        }
        Iterator<Integer> iter = items.iterator();
        while (iter.hasNext()) StdOut.print(iter.next() + " ");
        StdOut.println(" size: " + items.size());

        iter = items.iterator();
        while (iter.hasNext()) StdOut.print(iter.next() + " ");
        StdOut.println(" size: " + items.size());

        for (int j = 0; j < 30; j++) {
            for (int i = 0; i < 3; i++) {
                items.dequeue();
            }
            iter = items.iterator();
            while (iter.hasNext()) StdOut.print(iter.next());
            StdOut.println(" size: " + items.size());
        }
    }

    private void nullCheck(Item item) {
        if (item == null) throw new IllegalArgumentException();
    }

    private void nullCheck() {
        if (isEmpty()) throw new NoSuchElementException();
    }

    private void resize(int newLength) {
        assert newLength >= size;

        Item[] temp = (Item[]) new Object[newLength];
        System.arraycopy(items, 0, temp, 0, size);
        items = temp;
    }

}
